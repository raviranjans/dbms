create view vfood as
select foodname
from food;
